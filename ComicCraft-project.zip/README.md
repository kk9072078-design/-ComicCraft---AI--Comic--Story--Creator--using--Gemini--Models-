# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI + Jinja2 web application that turns a user's story idea into a five-panel comic. The documented workflow is preserved: structured outline -> detailed narration/dialogue -> panel illustrations -> layout -> PDF export.

## Architecture

- **Frontend:** HTML + CSS + Jinja2
- **Backend:** FastAPI
- **Story AI:** Google Gemini via the current `google-genai` SDK
- **Images:** Hugging Face Inference API when enabled; deterministic local placeholders otherwise
- **PDF:** fpdf2 + Pillow

The original specification describes Gemini Flash, Gemini Pro, and Stable Diffusion as the three AI stages and identifies the main input fields as story prompt, character, setting, tone, and art style. See the supplied documentation. 

## Project structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── schemas.py
│   ├── routes.py
│   └── services/
│       ├── __init__.py
│       ├── comic_service.py
│       ├── gemini_flash.py
│       ├── gemini_pro.py
│       ├── image_generator.py
│       ├── layout_builder.py
│       └── exporters.py
├── static/
│   ├── css/style.css
│   ├── panels/.gitkeep
│   └── exports/.gitkeep
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── tests/test_app.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Quick start — Windows / VS Code

1. Open the `ComicCraft` folder in VS Code.
2. Open **Terminal -> New Terminal**.
3. Create a virtual environment:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```bat
.venv\Scripts\activate.bat
```

4. Install dependencies:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

5. Copy `.env.example` to `.env` and add your Gemini API key.
6. Start the app:

```powershell
uvicorn app.main:app --reload
```

7. Open `http://127.0.0.1:8000`.
8. API docs: `http://127.0.0.1:8000/docs`.

## AI image mode

The application is deliberately runnable without a GPU. With `ENABLE_AI_IMAGES=0`, it creates local placeholder panel art, allowing you to test the complete UI, API, layout, and PDF pipeline without downloading a multi-gigabyte diffusion model.

To use Hugging Face image generation:

```env
HF_API_KEY=hf_xxxxxxxxx
ENABLE_AI_IMAGES=1
HF_IMAGE_MODEL=stabilityai/stable-diffusion-xl-base-1.0
```

A hosted inference endpoint is used rather than loading Stable Diffusion into your laptop's RAM/VRAM. This is the practical equivalent of the documented Stable Diffusion image-generation stage while keeping local setup manageable.

## API

### POST `/generate-comic/json`

```json
{
  "story_prompt": "A brave fox explores an enchanted forest.",
  "character_name": "Kira",
  "setting": "Enchanted forest",
  "tone": "dramatic",
  "art_style": "comic book"
}
```

Returns the generated five-panel layout and PDF URL.

### POST `/test-image`

```json
{"prompt":"A fox hero in an enchanted forest, comic book art"}
```

### POST `/generate`

Browser form endpoint that renders the comic preview.

## Testing

Run:

```powershell
pytest -q
```

The tests do not call external AI services. They validate routes, schema validation, layout building, placeholder image generation, and PDF export.

## Troubleshooting

- **Gemini error:** check `GEMINI_API_KEY` and the configured model IDs in `.env`.
- **HF image error:** check `HF_API_KEY`, model availability, and network access. Temporarily set `ENABLE_AI_IMAGES=0` to verify the rest of the app.
- **PDF/image problem:** make sure Pillow and fpdf2 installed successfully.
- **Port busy:** use `uvicorn app.main:app --reload --port 8001`.
