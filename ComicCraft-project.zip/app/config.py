from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    gemini_api_key: str = ""
    hf_api_key: str = ""
    gemini_flash_model: str = "gemini-2.5-flash"
    gemini_pro_model: str = "gemini-2.5-pro"
    hf_image_model: str = "stabilityai/stable-diffusion-xl-base-1.0"
    enable_ai_images: bool = False
    static_dir: Path = BASE_DIR / "static"
    template_dir: Path = BASE_DIR / "templates"

    model_config = SettingsConfigDict(env_file=BASE_DIR / ".env", env_file_encoding="utf-8", extra="ignore")

@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    (settings.static_dir / "panels").mkdir(parents=True, exist_ok=True)
    (settings.static_dir / "exports").mkdir(parents=True, exist_ok=True)
    return settings
