from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from app.config import get_settings
from app.schemas import ImageTestRequest, PromptRequest
from app.services.comic_service import generate_comic
from app.services.image_generator import generate_image

templates = Jinja2Templates(directory=get_settings().template_dir)
router = APIRouter()

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"error": None})

@router.post("/generate", response_class=HTMLResponse)
async def generate_form(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = PromptRequest(story_prompt=story_prompt, character_name=character_name, setting=setting, tone=tone, art_style=art_style)
        layout, pdf_path = generate_comic(data)
        return templates.TemplateResponse(request=request, name="comic_preview.html", context={"layout": layout, "pdf_path": pdf_path, "character_name": data.character_name})
    except Exception as exc:
        return templates.TemplateResponse(request=request, name="index.html", context={"error": str(exc)})

@router.post("/generate-comic/json")
async def generate_json(payload: PromptRequest):
    try:
        layout, pdf_path = generate_comic(payload)
        return {"success": True, "character_name": payload.character_name, "layout": layout, "pdf_path": pdf_path}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Comic generation failed: {exc}") from exc

@router.post("/test-image")
async def test_image(payload: ImageTestRequest):
    try:
        return {"success": True, "image_path": generate_image(payload.prompt)}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Image generation failed: {exc}") from exc

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request):
    return templates.TemplateResponse(request=request, name="export_success.html", context={})

@router.get("/health")
async def health():
    settings = get_settings()
    return {"status": "ok", "gemini_configured": bool(settings.gemini_api_key), "ai_images_enabled": settings.enable_ai_images}
