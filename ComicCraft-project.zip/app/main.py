from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.config import get_settings
from app.routes import router

settings = get_settings()
app = FastAPI(title=settings.app_name, version="1.0.0", description="AI-powered five-panel comic creator")
app.mount("/static", StaticFiles(directory=settings.static_dir), name="static")
app.include_router(router)
