def build_comic_layout(outline: list[dict], story: list[dict], image_paths: list[str]) -> list[dict]:
    if not (len(outline) == len(story) == len(image_paths)):
        raise ValueError("Outline, story and image counts must match.")
    layout = []
    for panel, narrative, image in zip(outline, story, image_paths):
        layout.append({
            "panel_number": panel["panel_number"],
            "title": panel["title"],
            "image_path": image,
            "scene_description": panel["scene_description"],
            "image_prompt": panel["image_prompt"],
            "caption": narrative["caption"],
            "narration": narrative["narration"],
            "dialogue": narrative["dialogue"],
        })
    return layout
