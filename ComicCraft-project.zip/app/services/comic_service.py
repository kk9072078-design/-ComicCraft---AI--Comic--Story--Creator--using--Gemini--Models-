from app.schemas import PromptRequest
from .gemini_flash import generate_outline
from .gemini_pro import generate_story
from .image_generator import generate_image
from .layout_builder import build_comic_layout
from .exporters import save_pdf


def generate_comic(request: PromptRequest) -> tuple[list[dict], str]:
    outline = generate_outline(
        request.story_prompt, request.character_name, request.setting,
        request.tone, request.art_style,
    )
    story = generate_story(outline, request.character_name, request.tone)
    image_paths = [
        generate_image(f"{panel['image_prompt']}. Consistent character: {request.character_name}.")
        for panel in outline
    ]
    layout = build_comic_layout(outline, story, image_paths)
    pdf_path = save_pdf(layout, f"{request.character_name}'s Comic")
    return layout, pdf_path
