import json
import re
from typing import Any

from .gemini_client import generate_text

from app.config import get_settings


def _extract_json(text: str) -> Any:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    start = cleaned.find("[")
    end = cleaned.rfind("]")
    if start == -1 or end == -1:
        raise ValueError("Gemini did not return a JSON array.")
    return json.loads(cleaned[start:end + 1])


def generate_outline(story_prompt: str, character_name: str, setting: str, tone: str, art_style: str) -> list[dict]:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")

    response_text = generate_text(settings.gemini_flash_model, prompt, temperature=0.8)
    data = _extract_json(response_text)
    if not isinstance(data, list) or len(data) != 5:
        raise ValueError("Outline must contain exactly five panels.")
    required = {"panel_number", "title", "scene_description", "image_prompt"}
    normalized = []
    for i, panel in enumerate(data, start=1):
        if not isinstance(panel, dict) or not required.issubset(panel):
            raise ValueError(f"Panel {i} has an invalid structure.")
        normalized.append({
            "panel_number": i,
            "title": str(panel["title"]).strip(),
            "scene_description": str(panel["scene_description"]).strip(),
            "image_prompt": str(panel["image_prompt"]).strip(),
        })
    return normalized
