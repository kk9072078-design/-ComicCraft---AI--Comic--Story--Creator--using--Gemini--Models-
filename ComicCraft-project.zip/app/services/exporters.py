from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from fpdf import FPDF
from PIL import Image
from app.config import get_settings


def _image_file(url_path: str) -> Path:
    return get_settings().static_dir / urlparse(url_path).path.removeprefix("/static/")


def _pdf_text(value: str) -> str:
    return str(value).encode("latin-1", "replace").decode("latin-1")


def save_pdf(layout: list[dict], title: str = "ComicCraft Comic") -> str:
    settings = get_settings()
    filename = f"comic-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.pdf"
    output = settings.static_dir / "exports" / filename
    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.set_x(15)
        pdf.multi_cell(180, 10, _pdf_text(f"Panel {panel['panel_number']}: {panel['title']}"))
        pdf.ln(3)
        image_file = _image_file(panel["image_path"])
        if image_file.exists():
            with Image.open(image_file) as im:
                w, h = im.size
            max_w, max_h = 180, 105
            scale = min(max_w / w, max_h / h)
            image_w, image_h = w * scale, h * scale
            image_x = (210 - image_w) / 2
            image_y = pdf.get_y()
            pdf.image(str(image_file), x=image_x, y=image_y, w=image_w, h=image_h)
            pdf.set_y(image_y + image_h + 8)
        pdf.set_x(15)
        pdf.set_font("Helvetica", "I", 11)
        pdf.set_x(15)
        pdf.multi_cell(180, 6, _pdf_text(panel["scene_description"]))
        pdf.ln(3)
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_x(15)
        pdf.multi_cell(180, 6, _pdf_text(panel["caption"]))
        pdf.set_font("Helvetica", "", 11)
        pdf.set_x(15)
        pdf.multi_cell(180, 6, _pdf_text(panel["narration"]))
        for line in panel["dialogue"]:
            pdf.ln(1)
            pdf.set_x(15)
        pdf.multi_cell(180, 6, _pdf_text(f'"{line}"'))

    pdf.output(str(output))
    return f"/static/exports/{filename}"
