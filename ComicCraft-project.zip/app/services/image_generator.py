from pathlib import Path
import hashlib
import re
import textwrap
import httpx
from PIL import Image, ImageDraw, ImageFont
from app.config import get_settings


def _safe_name(prompt: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", prompt.lower()).strip("-")[:48]
    digest = hashlib.sha256(prompt.encode()).hexdigest()[:10]
    return f"{slug or 'panel'}-{digest}.png"


def _placeholder(prompt: str, path: Path) -> Path:
    image = Image.new("RGB", (1024, 576), "#f1eadb")
    draw = ImageDraw.Draw(image)
    draw.rectangle((18, 18, 1006, 558), outline="#171717", width=8)
    draw.text((45, 45), "COMICCRAFT", fill="#171717")
    lines = textwrap.wrap(prompt, width=58)[:10]
    y = 180
    for line in lines:
        draw.text((55, y), line, fill="#171717")
        y += 36
    draw.text((55, 500), "AI image mode disabled — local test artwork", fill="#555555")
    image.save(path, format="PNG")
    return path


def generate_image(prompt: str) -> str:
    settings = get_settings()
    path = settings.static_dir / "panels" / _safe_name(prompt)
    if path.exists():
        return f"/static/panels/{path.name}"

    if not settings.enable_ai_images or not settings.hf_api_key:
        return f"/static/panels/{_placeholder(prompt, path).name}"

    url = f"https://api-inference.huggingface.co/models/{settings.hf_image_model}"
    headers = {"Authorization": f"Bearer {settings.hf_api_key}"}
    try:
        with httpx.Client(timeout=180) as client:
            response = client.post(url, headers=headers, json={"inputs": prompt})
            response.raise_for_status()
            content_type = response.headers.get("content-type", "")
            if "image" not in content_type:
                raise RuntimeError(response.text[:500])
            path.write_bytes(response.content)
    except Exception as exc:
        # A failed optional image provider must not destroy the story/PDF pipeline.
        _placeholder(f"Image service unavailable. Prompt: {prompt}\nError: {exc}", path)
    return f"/static/panels/{path.name}"
