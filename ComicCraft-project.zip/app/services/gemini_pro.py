import json
import re
from app.config import get_settings
from .gemini_client import generate_text


def _extract_json(text: str):
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    start, end = cleaned.find("["), cleaned.rfind("]")
    if start < 0 or end < 0:
        raise ValueError("Gemini did not return a JSON array.")
    return json.loads(cleaned[start:end + 1])


def generate_story(outline: list[dict], character_name: str, tone: str) -> list[dict]:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")

    response_text = generate_text(settings.gemini_pro_model, prompt, temperature=0.85)
    data = _extract_json(response_text)
    if not isinstance(data, list) or len(data) != 5:
        raise ValueError("Story must contain exactly five panels.")

    result = []
    for i, panel in enumerate(data, start=1):
        dialogue = panel.get("dialogue", [])
        if isinstance(dialogue, str):
            dialogue = [dialogue]
        result.append({
            "panel_number": i,
            "caption": str(panel.get("caption", "")).strip(),
            "narration": str(panel.get("narration", "")).strip(),
            "dialogue": [str(x).strip() for x in dialogue if str(x).strip()],
        })
    return result
